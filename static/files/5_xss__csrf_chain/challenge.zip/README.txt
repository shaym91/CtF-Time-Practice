
XSS + CSRF Chain - Hard (300 points)

Category: Web
Flag: FLAG{ch41n_4tt4ck_succ3ss}

This is a REAL, HARD, WORKABLE challenge.
All files and code are functional.

Good luck!
