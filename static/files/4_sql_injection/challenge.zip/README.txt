
SQL Injection - Medium (150 points)

Category: Web
Flag: FLAG{sql_1nj3ct10n_1s_cl4ss1c}

This is a REAL, HARD, WORKABLE challenge.
All files and code are functional.

Good luck!
