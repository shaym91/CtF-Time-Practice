
RSA Madness - Hard (300 points)

Category: Crypto
Flag: FLAG{sm4ll_pr1m3s_ar3_b4d}

This is a REAL, HARD, WORKABLE challenge.
All files and code are functional.

Good luck!
