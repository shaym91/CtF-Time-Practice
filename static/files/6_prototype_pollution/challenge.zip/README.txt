
Prototype Pollution - Insane (500 points)

Category: Web
Flag: FLAG{pr0t0typ3_p011ut10n_rc3}

This is a REAL, HARD, WORKABLE challenge.
All files and code are functional.

Good luck!
